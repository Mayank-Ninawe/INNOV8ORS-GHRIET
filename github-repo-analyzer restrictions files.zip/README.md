# 🚀 GitHub Repo Analyzer

![Next.js](https://img.shields.io/badge/Next.js-000?logo=next.js&logoColor=white)
![License](https://img.shields.io/badge/License-CC--BY--NC--ND%204.0-blue)
![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)
![Contributions](https://img.shields.io/github/contributors/UtkarshPatrikar/github-repo-analyzer)

> ✨ A modern and scalable frontend built with **Next.js**, consuming data via REST APIs to deliver a fast and interactive GitHub analysis tool.

---

## ✨ Features

- ⚡ Blazing fast performance with Next.js
- 🔌 REST API integration
- ♻️ Reusable components
- 📱 Mobile-first responsive design
- 🎨 Styled with Tailwind CSS

---

## 🚀 Getting Started

```bash
# Clone the repository
git clone https://github.com/UtkarshPatrikar/github-repo-analyzer.git

# Navigate into the project
cd github-repo-analyzer

# Install dependencies
npm install

# Start development server
npm run dev
```

Create a `.env.local` file to store your environment variables like API URLs.

---

## 🛡️ License & Usage

This project is protected under the [**CC BY-NC-ND 4.0 License**](LICENSE).

```txt
✔️ Personal/Educational Use
❌ No Commercial Use
❌ No Modifications
❌ No Reposting Without Credit
```

[![License: CC BY-NC-ND 4.0](https://licensebuttons.net/l/by-nc-nd/4.0/88x31.png)](https://creativecommons.org/licenses/by-nc-nd/4.0/)

---

## 🤝 Contributing

We welcome clean and respectful contributions!

Please read our [📄 Contribution Guidelines](CONTRIBUTING.md) and [📜 Code of Conduct](CODE_OF_CONDUCT.md) before submitting a PR.

---

## 👨‍💻 Author

Made with ❤️ by **Utkarsh Patrikar**  
[GitHub](https://github.com/UtkarshPatrikar)
